package com.murach.tipcalculator;

import android.content.Context;
import android.os.Bundle;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import  android.widget.SimpleAdapter;
import java.util.ArrayList;

public class TipHistoryActivity extends Activity {
    private ListView tipHistoryListView;
    private TipDB db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip_history);

        //get references to widget
        tipHistoryListView = (ListView)findViewById(R.id.tiphistorylistview);

        //GET DATABASE OBJECT
        db = new TipDB(this);
    }

    public void onResume(){
        super.onResume();

        //get tips from arraylist
        ArrayList<Tip> tips = db.getTips();
        TipHistoryAdapter adapter = new TipHistoryAdapter(this, tips);
        tipHistoryListView.setAdapter(adapter);

    }

}
