package com.murach.tipcalculator;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by knork on 7/3/2017.
 */

public class TipLayout extends RelativeLayout implements View.OnClickListener{

    // define variables for the widgets

    private TextView billAmountTextView;
    private TextView billDateTextView;
    private TextView tipPercentTextView;
    private Button deleteButton;

    private Context context;
    private TipDB db;
    private Tip tip;

    public TipLayout(Context context) {super(context);};

    public TipLayout(Context context, Tip tip){
        super(context);
        this.context = context;

        //get db object
        db = new TipDB(context);

        //inflate the layout
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.listview_tip, this, true);

        //get references to widgets
        billAmountTextView = (TextView) findViewById(R.id.billAmountTextView);
        billDateTextView = (TextView) findViewById(R.id.billDateTextView);
        tipPercentTextView = (TextView) findViewById(R.id.tipPercentTextView);
        deleteButton = (Button) findViewById(R.id.deleteButton);

        //set listeners
        deleteButton.setOnClickListener(this);

        //set task data on widgets
        setTip(tip);
    }
    public void setTip(Tip tip){
        this.tip = tip;

        //set the tip with formatting
        billDateTextView.setText(tip.getDateStringFormatted());

        //set the bill amount with formatting
        billAmountTextView.setText(tip.getBillAmountFormatted());

        //set the tip percent with formatting
        tipPercentTextView.setText(tip.getTipPercentFormatted());
    }
    @Override
    public void onClick(View v){
        db.deleteTip(tip.getId());
        context.startActivity(new Intent(context, TipHistoryActivity.class));
    }
}
