package com.murach.tipcalculator;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;

/**
 * Created by knork on 7/10/2017.
 */

public class TipProvider extends ContentProvider
{
    public static final String AUTHORITY = "com.murach.tipcalculator.provider";

    public static final int NO_MATCH = -1;
    public static final int ALL_TIPS_URI = 0;

    private TipDB db;
    private UriMatcher uriMatcher;

    @Override
    public boolean onCreate() {
        db = new TipDB(getContext());

        uriMatcher = new UriMatcher(NO_MATCH);
        uriMatcher.addURI(AUTHORITY, "tips", ALL_TIPS_URI);

        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] columns, String where,
                        String[] whereArgs, String orderBy) {
        switch(uriMatcher.match(uri)) {
            case ALL_TIPS_URI:
                return db.queryTips(columns, where,
                        whereArgs, orderBy);
            default:
                throw new UnsupportedOperationException (
                        "URI " + uri + " is not supported.");
        }
    }

    @Override
    public String getType(Uri uri) {
        switch(uriMatcher.match(uri)) {
            case ALL_TIPS_URI:
                return "vnd.android.cursor.dir/vnd.murach.tipcalculator.tips";

            default:
                throw new UnsupportedOperationException(
                        "URI " + uri + " is not supported.");
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        switch(uriMatcher.match(uri)) {
            case ALL_TIPS_URI:
                long insertId = db.insertTip(values);
                getContext().getContentResolver().notifyChange(uri, null);
                return uri.buildUpon().appendPath(
                        Long.toString(insertId)).build();
            default:
                throw new UnsupportedOperationException(
                        "URI: " + uri + " is not supported.");
        }
    }

    @Override
    public int update(Uri uri, ContentValues values, String where,
                      String[] whereArgs) {
        int updateCount;
        switch(uriMatcher.match(uri)) {

            case ALL_TIPS_URI:
                updateCount = db.updateTip(values, where, whereArgs);
                getContext().getContentResolver().notifyChange(uri, null);
                return updateCount;
            default:
                throw new UnsupportedOperationException (
                        "URI " + uri + " is not supported.");
        }
    }

    @Override
    public int delete(Uri uri, String where, String[] whereArgs) {
        int deleteCount;
        switch(uriMatcher.match(uri)) {

            case ALL_TIPS_URI:
                deleteCount = db.deleteTip(where, whereArgs);
                getContext().getContentResolver().notifyChange(uri, null);
                return deleteCount;
            default:
                throw new UnsupportedOperationException (
                        "URI " + uri + " is not supported.");
        }
    }
}//end of TipProvider
